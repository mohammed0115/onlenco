"""
Translation dictionary, ported from src/lib/i18n.tsx in the React app.

Keys match the React app exactly so the templates can use the same
identifiers and the wording stays identical.
"""

DICT = {
    # Nav
    "nav.features":   {"en": "Features",     "ar": "المميزات"},
    "nav.curriculum": {"en": "Curriculum",   "ar": "المنهج"},
    "nav.pricing":    {"en": "Pricing",      "ar": "الأسعار"},
    "nav.signin":     {"en": "Sign in",      "ar": "تسجيل الدخول"},
    "nav.start":      {"en": "Start free",   "ar": "ابدأ مجاناً"},

    # Hero
    "hero.badge":   {"en": "Built for Sudanese learners 🇸🇩",
                     "ar": "مصمم للمتعلمين السودانيين 🇸🇩"},
    "hero.title1":  {"en": "Speak English with", "ar": "تحدث الإنجليزية"},
    "hero.title2":  {"en": "confidence.",        "ar": "بثقة."},
    "hero.subtitle": {
        "en": "Onlenco is your AI-powered English coach. Take a smart placement "
              "test, learn at your level, and practice speaking with an AI tutor "
              "any time.",
        "ar": "أونلنكو هو مدربك الذكي للغة الإنجليزية. اختبار تحديد مستوى ذكي، "
              "دروس على مستواك، وتدرب على المحادثة مع مدرس ذكي في أي وقت.",
    },
    "hero.cta":  {"en": "Take the placement test", "ar": "ابدأ اختبار التحديد"},
    "hero.cta2": {"en": "See how it works",        "ar": "كيف يعمل"},
    "hero.stat1": {"en": "CEFR levels A0–C2", "ar": "جميع المستويات A0–C2"},
    "hero.stat2": {"en": "AI voice tutor",    "ar": "مدرس صوتي ذكي"},
    "hero.stat3": {"en": "Pay with Bankak / Fawry", "ar": "ادفع ببنكك / فوري"},

    # Features
    "feat.title":    {"en": "Everything you need to learn", "ar": "كل ما تحتاجه للتعلم"},
    "feat.subtitle": {"en": "Four skills, one platform, your pace.",
                      "ar": "أربع مهارات، منصة واحدة، بسرعتك أنت."},
    "feat.placement.t": {"en": "AI Placement Test",         "ar": "اختبار تحديد المستوى"},
    "feat.placement.d": {"en": "Written + speaking assessment to find your CEFR level instantly.",
                         "ar": "اختبار كتابي وشفهي لتحديد مستوى CEFR فوراً."},
    "feat.tutor.t":   {"en": "AI Voice Tutor", "ar": "مدرس صوتي"},
    "feat.tutor.d":   {"en": "Real conversations with pronunciation feedback in real time.",
                       "ar": "محادثات حقيقية مع تصحيح النطق فورياً."},
    "feat.lessons.t": {"en": "Structured Lessons", "ar": "دروس منظمة"},
    "feat.lessons.d": {"en": "Reading, writing, listening, speaking — all video-led.",
                       "ar": "قراءة، كتابة، استماع، محادثة — بالفيديو."},
    "feat.club.t":    {"en": "Weekly English Club", "ar": "نادي الإنجليزية الأسبوعي"},
    "feat.club.d":    {"en": "Live discussions over Google Meet on real topics.",
                       "ar": "نقاشات حية عبر Google Meet حول مواضيع واقعية."},
    "feat.library.t": {"en": "Digital Library", "ar": "المكتبة الرقمية"},
    "feat.library.d": {"en": "Novels, short stories, grammar books — anytime.",
                       "ar": "روايات، قصص قصيرة، كتب قواعد — في أي وقت."},
    "feat.pay.t":     {"en": "Local Payments", "ar": "دفع محلي"},
    "feat.pay.d":     {"en": "Bankak, Fawry Sudan, O-Cash. Upload proof, get approved.",
                       "ar": "بنكك، فوري السودان، أو-كاش. ارفع الإيصال واحصل على الموافقة."},

    # Curriculum
    "cur.title":    {"en": "A path from A0 to C2", "ar": "رحلة من A0 إلى C2"},
    "cur.subtitle": {"en": "Each level unlocks new skills, content, and challenges.",
                     "ar": "كل مستوى يفتح مهارات ومحتوى وتحديات جديدة."},

    # Pricing
    "price.title":    {"en": "Simple, fair pricing", "ar": "أسعار بسيطة وعادلة"},
    "price.subtitle": {"en": "Pay locally with Bankak, Fawry, or O-Cash.",
                       "ar": "ادفع محلياً ببنكك أو فوري أو أو-كاش."},
    "price.month":    {"en": "Monthly",     "ar": "شهري"},
    "price.quarter":  {"en": "Quarterly",   "ar": "ربع سنوي"},
    "price.popular":  {"en": "Most popular", "ar": "الأكثر شيوعاً"},
    "price.cta":      {"en": "Get started",  "ar": "ابدأ الآن"},
    "price.permonth": {"en": "/ month",      "ar": "/ شهر"},
    "price.save":     {"en": "Save 25%",     "ar": "وفر 25%"},

    # Auth
    "auth.signin":   {"en": "Welcome back",        "ar": "مرحباً بعودتك"},
    "auth.signup":   {"en": "Create your account", "ar": "إنشاء حساب"},
    "auth.name":     {"en": "Full name",           "ar": "الاسم الكامل"},
    "auth.email":    {"en": "Email",               "ar": "البريد الإلكتروني"},
    "auth.password": {"en": "Password",            "ar": "كلمة المرور"},
    "auth.have":     {"en": "Already have an account?", "ar": "لديك حساب بالفعل؟"},
    "auth.no":       {"en": "Don't have an account?",   "ar": "ليس لديك حساب؟"},
    "auth.continue": {"en": "Continue",            "ar": "متابعة"},

    # Dashboard
    "dash.welcome":       {"en": "Welcome back", "ar": "مرحباً بعودتك"},
    "dash.takeplacement": {"en": "Start your placement test",
                           "ar": "ابدأ اختبار تحديد المستوى"},
    "dash.placementdesc": {"en": "Find your CEFR level so we can personalize your lessons.",
                           "ar": "حدد مستواك في CEFR لنخصص دروسك."},
    "dash.lessons":     {"en": "Your lessons",          "ar": "دروسك"},
    "dash.locked":      {"en": "Subscribe to unlock",   "ar": "اشترك لفتح المحتوى"},
    "dash.level":       {"en": "Level",                  "ar": "المستوى"},
    "dash.signout":     {"en": "Sign out",              "ar": "تسجيل الخروج"},
    "dash.subscribe":   {"en": "Subscribe",             "ar": "اشترك"},

    # Placement
    "pl.title": {"en": "AI Placement Test", "ar": "اختبار تحديد المستوى"},
    "pl.intro": {"en": "Answer a few questions and tell us about yourself in English. "
                       "Our AI will determine your CEFR level.",
                 "ar": "أجب على بعض الأسئلة وحدثنا عن نفسك بالإنجليزية. سيحدد الذكاء الاصطناعي مستواك."},
    "pl.q1":    {"en": "Choose the correct option: 'She ___ to school every day.'",
                 "ar": "اختر الإجابة الصحيحة: 'She ___ to school every day.'"},
    "pl.q2":    {"en": "Which sentence is grammatically correct?",
                 "ar": "أي جملة صحيحة قواعدياً؟"},
    "pl.q3":    {"en": "Write 2-3 sentences about your hobbies in English.",
                 "ar": "اكتب 2-3 جمل عن هواياتك بالإنجليزية."},
    "pl.q4":    {"en": "Describe what you did yesterday in English (4-6 sentences).",
                 "ar": "صف ما فعلته بالأمس بالإنجليزية (4-6 جمل)."},
    "pl.submit":    {"en": "Get my level", "ar": "احصل على مستواي"},
    "pl.analyzing": {"en": "AI is analyzing your answers…",
                     "ar": "الذكاء الاصطناعي يحلل إجاباتك…"},
    "pl.result":    {"en": "Your CEFR level is", "ar": "مستواك في CEFR هو"},
    "pl.continue":  {"en": "Continue to lessons", "ar": "متابعة إلى الدروس"},

    # Payments (new — these weren't in the React version yet)
    "pay.title":     {"en": "Subscribe to Onlenco",
                      "ar": "اشترك في أونلنكو"},
    "pay.intro":     {"en": "Choose a plan, transfer the amount, and upload a screenshot. "
                            "Our team verifies within 24 hours.",
                      "ar": "اختر خطة، حوّل المبلغ، وارفع لقطة الشاشة. فريقنا يتحقق خلال 24 ساعة."},
    "pay.method":    {"en": "Payment method", "ar": "وسيلة الدفع"},
    "pay.plan":      {"en": "Plan", "ar": "الخطة"},
    "pay.txn":       {"en": "Transaction reference", "ar": "رقم العملية"},
    "pay.proof":     {"en": "Upload screenshot", "ar": "ارفع لقطة الشاشة"},
    "pay.submit":    {"en": "Submit for review", "ar": "أرسل للمراجعة"},
    "pay.pending":   {"en": "Your payment is pending verification.",
                      "ar": "دفعتك قيد المراجعة."},
    "pay.active":    {"en": "Your subscription is active.",
                      "ar": "اشتراكك مفعل."},
    "pay.history":   {"en": "Payment history", "ar": "سجل المدفوعات"},
    "pay.instructions": {
        "en": "Send the amount to one of the accounts below, then upload your "
              "transfer screenshot. The admin will activate your subscription "
              "after verifying.",
        "ar": "أرسل المبلغ إلى أحد الحسابات أدناه، ثم ارفع لقطة شاشة التحويل. "
              "سيقوم المسؤول بتفعيل اشتراكك بعد التحقق.",
    },
}
