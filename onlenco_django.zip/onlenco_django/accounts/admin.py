from django.contrib import admin
from .models import Profile


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "full_name", "role", "cefr_level",
                    "subscription_status", "placement_completed", "created_at")
    list_filter = ("role", "subscription_status", "cefr_level", "placement_completed")
    search_fields = ("full_name", "user__email", "user__username")
    readonly_fields = ("created_at", "updated_at")
