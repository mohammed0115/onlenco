from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.views.decorators.http import require_http_methods

from .forms import PaymentSubmissionForm
from .models import PLAN_DETAILS


# Static account info shown to students for offline transfer.
# In production, edit these in `settings.py`, env vars, or a small
# DB-backed config table — the template only needs `label`, `account`,
# and `name`, so the shape stays simple.
ACCOUNT_INFO = {
    "bankak": {"label": "Bankak", "account": "1234 5678 9012",   "name": "Onlenco Sudan"},
    "fawry":  {"label": "Fawry",  "account": "+249 91 234 5678", "name": "Onlenco Sudan"},
    "ocash":  {"label": "O-Cash", "account": "+249 92 876 5432", "name": "Onlenco Sudan"},
}


@login_required
@require_http_methods(["GET", "POST"])
def subscribe(request):
    """Pick a plan + payment method, view destination account, upload a
    screenshot. Submission lands as `pending` until an admin approves it
    from /admin/."""

    profile = request.user.profile

    if request.method == "POST":
        form = PaymentSubmissionForm(request.POST, request.FILES)
        if form.is_valid():
            form.save(user=request.user)
            profile.subscription_status = "pending"
            profile.save(update_fields=["subscription_status"])
            messages.success(
                request,
                "Payment submitted! We'll verify it within 24 hours.",
            )
            return redirect("payment_history")
    else:
        form = PaymentSubmissionForm()

    return render(request, "payments/subscribe.html", {
        "form": form,
        "accounts": ACCOUNT_INFO,
        "plans": PLAN_DETAILS,
        "profile": profile,
        "submissions": request.user.payment_submissions.all()[:5],
    })


@login_required
def payment_history(request):
    return render(request, "payments/history.html", {
        "submissions": request.user.payment_submissions.all(),
        "profile": request.user.profile,
    })
