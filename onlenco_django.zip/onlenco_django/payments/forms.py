from django import forms

from .models import PaymentSubmission, PLAN_DETAILS


class PaymentSubmissionForm(forms.ModelForm):
    class Meta:
        model = PaymentSubmission
        fields = ["plan", "method", "transaction_reference", "screenshot"]
        widgets = {
            "transaction_reference": forms.TextInput(
                attrs={"placeholder": "e.g. TRX-908123 or last 4 digits"}
            ),
        }

    def clean_screenshot(self):
        f = self.cleaned_data["screenshot"]
        if f.size > 5 * 1024 * 1024:
            raise forms.ValidationError("Image must be 5 MB or smaller.")
        return f

    def save(self, user, commit=True):
        obj = super().save(commit=False)
        obj.user = user
        obj.amount_sdg = PLAN_DETAILS[obj.plan]["price_sdg"]
        if commit:
            obj.save()
        return obj
