from django.contrib import admin, messages

from .models import PaymentSubmission


@admin.register(PaymentSubmission)
class PaymentSubmissionAdmin(admin.ModelAdmin):
    list_display = ("user", "plan", "method", "amount_sdg",
                    "status", "created_at", "reviewed_at")
    list_filter = ("status", "method", "plan")
    search_fields = ("user__email", "user__username", "transaction_reference")
    readonly_fields = ("user", "plan", "method", "amount_sdg",
                       "transaction_reference", "screenshot",
                       "created_at", "reviewed_at", "reviewed_by")
    fieldsets = (
        (None, {
            "fields": ("user", "plan", "method", "amount_sdg",
                       "transaction_reference", "screenshot",
                       "status", "admin_note"),
        }),
        ("Review metadata", {
            "fields": ("created_at", "reviewed_at", "reviewed_by"),
        }),
    )
    actions = ("approve_payments", "reject_payments")

    @admin.action(description="✓ Approve selected payments (activates subscription)")
    def approve_payments(self, request, queryset):
        count = 0
        for payment in queryset.filter(status="pending"):
            payment.approve(reviewer=request.user)
            count += 1
        self.message_user(
            request,
            f"Approved {count} payment(s) and activated subscriptions.",
            level=messages.SUCCESS,
        )

    @admin.action(description="✗ Reject selected payments")
    def reject_payments(self, request, queryset):
        count = 0
        for payment in queryset.filter(status="pending"):
            payment.reject(reviewer=request.user, note="Rejected by admin.")
            count += 1
        self.message_user(
            request,
            f"Rejected {count} payment(s).",
            level=messages.WARNING,
        )
