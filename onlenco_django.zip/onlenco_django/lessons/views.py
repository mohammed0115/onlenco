from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from .models import Lesson


@login_required
def dashboard(request):
    """Student dashboard. Shows the placement-test prompt (if not yet
    taken), the lesson grid, and a subscribe CTA when the student isn't
    on an active plan."""

    profile = request.user.profile
    qs = Lesson.objects.all()

    # If the learner has a CEFR level, surface their level + the next two
    # levels so they can see the path forward without overwhelming them.
    if profile.cefr_level:
        order = ["A0", "A1", "A2", "B1", "B2", "C1", "C2"]
        try:
            i = order.index(profile.cefr_level)
            visible = order[i:i + 3]
            qs = qs.filter(level__in=visible)
        except ValueError:
            pass

    return render(request, "lessons/dashboard.html", {
        "profile": profile,
        "lessons": qs,
        "is_subscribed": profile.is_subscribed,
    })
