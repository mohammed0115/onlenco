from django.db import models

from accounts.models import CEFR_CHOICES


SKILL_CHOICES = [
    ("reading", "Reading"),
    ("writing", "Writing"),
    ("listening", "Listening"),
    ("speaking", "Speaking"),
]


class Lesson(models.Model):
    """A single video-led lesson tagged with skill and CEFR level."""

    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    skill = models.CharField(max_length=10, choices=SKILL_CHOICES)
    level = models.CharField(max_length=2, choices=CEFR_CHOICES)
    video_url = models.URLField(blank=True)
    duration_minutes = models.PositiveIntegerField(default=10)
    sort_order = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["sort_order", "level", "title"]

    def __str__(self):
        return f"[{self.level}] {self.title}"
