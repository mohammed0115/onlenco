"""Seed the database with an admin user and a small set of demo lessons.

Usage:
    python manage.py seed_demo
"""
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand

from lessons.models import Lesson


SAMPLE_LESSONS = [
    # (title, description, skill, level, duration, sort_order)
    ("Greetings & Introductions",
     "Learn how to say hello, introduce yourself, and ask basic questions.",
     "speaking", "A0",  8, 10),
    ("The Alphabet & Sounds",
     "Master English letter sounds and tricky pronunciation pairs.",
     "listening", "A0", 10, 20),
    ("Everyday Vocabulary",
     "Family, home, food — the 200 words you'll use daily.",
     "reading", "A1", 12, 30),
    ("Present Simple",
     "Build sentences in the present tense with confidence.",
     "writing", "A1", 14, 40),
    ("Asking for Directions",
     "Practical phrases for travel and getting around the city.",
     "speaking", "A2",  9, 50),
    ("Past Simple Stories",
     "Talk about what happened yesterday, last week, or last year.",
     "writing", "A2", 15, 60),
    ("Conversational Listening",
     "Train your ear with natural-speed dialogues and interviews.",
     "listening", "B1", 18, 70),
    ("Reading the News",
     "Decode article headlines and pull out the key information.",
     "reading", "B1", 16, 80),
    ("Workplace Email",
     "Write professional emails for requests, follow-ups, and updates.",
     "writing", "B2", 20, 90),
    ("Debate & Discussion",
     "Defend your opinion and respond to counterarguments live.",
     "speaking", "B2", 22, 100),
    ("Academic Reading",
     "Strategies for tackling dense, formal academic texts.",
     "reading", "C1", 24, 110),
    ("Native-level Idioms",
     "Idioms, collocations, and the small phrases that show fluency.",
     "speaking", "C2", 18, 120),
]


class Command(BaseCommand):
    help = "Create an admin user and seed demo lessons."

    def add_arguments(self, parser):
        parser.add_argument("--admin-email",    default="admin@onlenco.local")
        parser.add_argument("--admin-password", default="onlenco123")

    def handle(self, *args, **opts):
        User = get_user_model()
        email = opts["admin_email"].strip().lower()
        password = opts["admin_password"]

        admin, created = User.objects.get_or_create(
            username=email,
            defaults={"email": email, "is_staff": True, "is_superuser": True},
        )
        if created:
            admin.set_password(password)
            admin.is_staff = True
            admin.is_superuser = True
            admin.save()
            admin.profile.full_name = "Onlenco Admin"
            admin.profile.role = "admin"
            admin.profile.save()
            self.stdout.write(self.style.SUCCESS(
                f"Created admin {email!r} with password {password!r}."
            ))
        else:
            self.stdout.write(f"Admin user {email!r} already exists, skipping creation.")

        new_lessons = 0
        for title, desc, skill, level, dur, sort in SAMPLE_LESSONS:
            obj, created = Lesson.objects.get_or_create(
                title=title,
                defaults=dict(description=desc, skill=skill, level=level,
                              duration_minutes=dur, sort_order=sort),
            )
            if created:
                new_lessons += 1

        self.stdout.write(self.style.SUCCESS(
            f"Lessons: {new_lessons} added, {Lesson.objects.count()} total."
        ))
