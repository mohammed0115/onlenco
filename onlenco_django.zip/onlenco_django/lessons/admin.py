from django.contrib import admin
from .models import Lesson


@admin.register(Lesson)
class LessonAdmin(admin.ModelAdmin):
    list_display = ("title", "skill", "level", "duration_minutes", "sort_order", "created_at")
    list_filter = ("skill", "level")
    search_fields = ("title", "description")
    list_editable = ("sort_order",)
    ordering = ("sort_order", "level")
